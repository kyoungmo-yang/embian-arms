define([
  './dash',
  './dashLoader',
  './row',
  './submenuCtrl',
  './pulldown',
  './search',
  './settingsCtrl',
  './metricKeys'
  // './graphiteTarget',
  // './graphiteImport',
  // './influxTargetCtrl',
  // './playlistCtrl',
  // './inspectCtrl',
  // './opentsdbTargetCtrl',
], function () {});
 	