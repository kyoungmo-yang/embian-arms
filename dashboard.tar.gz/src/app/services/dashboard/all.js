define([
  './dashboardKeyBindings',
],
function () {});
