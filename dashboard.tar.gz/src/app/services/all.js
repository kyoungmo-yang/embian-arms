define([
  './alertSrv',
  './dashboard',
  './datasourceSrv',
  './filterSrv',
  './timer',
  './panelMove',
  './keyboardManager',
  './querySrv',
  './esVersion',
  './fields',
  './jquery.highlight-4'
  // './annotationsSrv',
  // './playlistSrv',
  // './unsavedChangesSrv',
],
function () {});