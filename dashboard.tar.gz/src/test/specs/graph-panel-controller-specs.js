/*define([
  'panels/graphite/module'
], function() {
  'use strict';

  describe('Graph panel controller', function() {
    var _graphPanelCtrl;

    beforeEach(module('kibana.panels.graphite'));
    beforeEach(module(function($provide){
      $provide.value('filterSrv',{});
    }));

    beforeEach(inject(function($controller, $rootScope) {
      _graphPanelCtrl = $controller('graphite', {
        $scope: $rootScope.$new()
      });
    }));

    describe('init', function() {
      beforeEach(function() {
      });

      it('asd', function() {

      });
    });
  });

});
*/