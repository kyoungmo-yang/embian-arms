module.exports = function(grunt) {
  grunt.registerTask('server', ['connect:dev']);
};