#!/bin/bash
MVN=/usr/bin/mvn

HOME_DIR="/opt/cep-engine-service"

cd $HOME_DIR
$MVN clean package